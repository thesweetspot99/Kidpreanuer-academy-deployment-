export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-white text-black">
      <h1 className="text-3xl font-bold">Kidpreneur Academy is Live!</h1>
    </main>
  )
}
